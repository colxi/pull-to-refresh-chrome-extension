# pull-to-refresh Chrome extension
Pull gesture implementation ( and mouse wheel/trackpad overscroll ) to reload the current webpage.

Allows quick and easy page refresh, in all kind of enviroments and devices:
- Pull down gesture, in touch devices
- Two fingers scroll in laptop trackpads
- Mousen Wheel scroll in mouse based enviroments

Available in:

https://chrome.google.com/webstore/detail/pull-to-refresh/opiolhkaggfkacemkinlcbidbidfpenl



